import React from 'react'

const SupplierEntryDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default SupplierEntryDetails
