import React, { useState } from 'react';
import Navbar from './Navbar';
import Enquiry from './Enquiry';

const Main = () => {

 
  return (
    <div>
      <Enquiry />
    </div>
  );
};





export default Main;
